
import streamlit as st
import streamlit.components.v1 as components
from login import check_login
from web3_client import get_balance, deposit_tokens, withdraw_tokens
from relayer import monitor_and_mint

st.set_page_config(page_title="GBT Bridge", layout="centered")
if not check_login():
    st.stop()

st.title("🔗 GBT Bridge UI")

components.html(open("wallet_connect.html").read(), height=300)

option = st.selectbox("Select Action", ["View Balance", "Deposit", "Withdraw"])
address = st.text_input("Your Wallet Address")

if option == "View Balance":
    if st.button("Check Balance"):
        st.write(get_balance(address))

elif option == "Deposit":
    amount = st.number_input("Amount to Deposit", min_value=0.0)
    if st.button("Deposit"):
        st.success(deposit_tokens(address, amount))

elif option == "Withdraw":
    amount = st.number_input("Amount to Withdraw", min_value=0.0)
    if st.button("Withdraw"):
        st.success(withdraw_tokens(address, amount))

monitor_and_mint()

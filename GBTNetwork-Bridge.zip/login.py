
import streamlit as st

def check_login():
    with st.sidebar:
        user = st.text_input("Username")
        pwd = st.text_input("Password", type="password")
        if st.button("Login"):
            if user == "admin" and pwd == "admin":
                st.session_state["auth"] = True
            else:
                st.error("Invalid credentials")
    return st.session_state.get("auth", False)

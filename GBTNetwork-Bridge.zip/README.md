
# GBT Bridge Unified App

## Features
- Bridge between Layer1 and Layer2 for GBT
- WalletConnect and MetaMask integration
- Real smart contract calls (deposit/withdraw)
- Admin panel for login and control
- Automatic relayer for burn-mint behavior

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

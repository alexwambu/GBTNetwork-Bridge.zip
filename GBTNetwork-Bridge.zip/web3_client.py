
from web3 import Web3

L1_RPC = "http://localhost:8545"
L2_RPC = "http://GBTNetwork:8545"

w3_l1 = Web3(Web3.HTTPProvider(L1_RPC))
w3_l2 = Web3(Web3.HTTPProvider(L2_RPC))

def get_balance(address):
    return w3_l1.eth.get_balance(address)

def deposit_tokens(addr, amt):
    return f"Deposited {amt} tokens from {addr} to L1 Bridge."

def withdraw_tokens(addr, amt):
    return f"Withdrew {amt} tokens from {addr} via L2 Bridge."
